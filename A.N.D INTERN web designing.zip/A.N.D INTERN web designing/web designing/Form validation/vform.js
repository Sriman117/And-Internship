function validation()
{
    let user = document.getElementById('Uname').value;
    let pass = document.getElementById('pswd').value;
    let confpass = document.getElementById('cpswd').value;
    let phno = document.getElementById('num').value;
    let mail = document.getElementById('emails').value;

    if(user==""){
        document.getElementById('username').innerHTML=" ** Please fill the Username field";
        return false;
    }
    if((user.length<=2) ||(user.length>20)){
        document.getElementById('username').innerHTML= " ** user length must be between 2 and 20";
        return false;
    }
    if(!isNaN(user)){
        document.getElementById('username').innerHTML= " ** only characters are allowed";
        return false;
    }

    if(pass==""){
        document.getElementById('pwd').innerHTML=" ** Please fill the Password field";
        return false;
    }
    if((pass.length <= 5) || (pass.length >20)){
        document.getElementById('pwd').innerHTML = " ** password length must be between 5 and 20";
        return false;
    }
 
    if(confpass==""){
        document.getElementById('confirmpwd').innerHTML=" ** Please fill the Confirm Password field";
        return false;
    }
    if(pass!=confpass){
        document.getElementById('confirmpwd').innerHTML= " ** password is not matched ";
        return false;
    }

    if(phno==""){
        document.getElementById('Mobileno').innerHTML=" ** Please fill the Mobile number field";
        return false;
    }
    // if(isNAN(phno)){
    //     document.getElementById('Mobileno').innerHTML=" ** only digits are allowed not characters";
    //     return false;
    // }
    if(phno.length!=10){
        document.getElementById('Mobileno').innerHTML=" ** Mobile number must be 10 digits";
        return false;
    }

    if(mail==""){
        document.getElementById('emailid').innerHTML=" ** Please fill the Email field";
        return false;
    }
    if(mail.indexOf('@') <= 0){
        document.getElementById('emailid').innerHTML=" ** Inavalid position";
        return false;
    }
    if ((mail.charAt(mail.length-4)!='.') && (mail.charAt(mail.length-3)!='.')){
        document.getElementById('emailid').innerHTML=" ** Inavalid mail id";
        return false;
    }

    // document.getElementById('sub').innerHTML="FORM SUBMITTED SUCCESSFULLY!";
}
 function myalert(){
    alert("FORM IS SUBMITTED SUCCESSFULLY!!")
 }